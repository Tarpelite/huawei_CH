
from hwdata.Car import   CarInst

def depature(car:CarInst):
    assert (car.status == CarInst.CAR_WAITING)


